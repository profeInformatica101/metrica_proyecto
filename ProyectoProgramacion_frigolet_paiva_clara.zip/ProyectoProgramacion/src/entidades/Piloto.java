/*
 * Clase Piloto
 */
package entidades;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author clara
 */
public class Piloto implements Comparable<Piloto> {
    private String nombre, apellido;
    private String nacionalidad;
    private int numero;
    private Equipo equipo;
    private List<Piloto> pilotos;

    public Piloto(String nombre, String apellido, int numero, String nacionalidad, Equipo equipo) {
        if (nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre del piloto no puede estar vac�o");
        } else {
            this.nombre = nombre;
        }
        this.apellido = apellido;
        this.numero = numero;
        this.nacionalidad = nacionalidad;
        this.equipo = null;
        this.pilotos = new ArrayList();
        this.equipo=equipo;

    }

    public void insertarPiloto(Piloto p) {
        pilotos.add(p);
    }

    public List<Piloto> getPilotos() {
        return pilotos;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    @Override
    public String toString() {
        return " " +nombre+ " "  + apellido +" "+ "("+numero+")" +" , " + nacionalidad + " Equipo: "+ equipo.getNombre();
    }

    @Override
    public int compareTo(Piloto o) {
        return this.nombre.compareToIgnoreCase(o.nombre);
    }

}
