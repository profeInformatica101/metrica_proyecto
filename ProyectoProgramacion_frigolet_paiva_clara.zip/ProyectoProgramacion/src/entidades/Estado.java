/*
 * Enum de estados de las apuestas
 */
package entidades;

/**
 *
 * @author clara
 */
public enum Estado {
    PENDIENTE,GANADA,PERDIDA;
}
