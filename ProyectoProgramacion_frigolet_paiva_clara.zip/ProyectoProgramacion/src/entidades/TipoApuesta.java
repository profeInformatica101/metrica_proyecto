/*
 * Clase Tipo apuesta
 */
package entidades;


/**
 *
 * @author clara
 */
public class TipoApuesta {

    private Tipo tipo;
    private String descripcion;

    public TipoApuesta(Tipo tipo, String descripcion) {
        this.tipo = tipo;
        this.descripcion = descripcion;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return tipo + " : " + descripcion;
    }

}
