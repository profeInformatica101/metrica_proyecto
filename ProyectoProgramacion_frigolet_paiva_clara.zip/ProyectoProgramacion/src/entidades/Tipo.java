/*
 * Enum con el tipo de apuestas que se pueden realizar
 */
package entidades;

/**
 *
 * @author clara
 */
public enum Tipo {
    GANADOR, PODIO, POLE_POSITION,VUELTA_RAPIDA, ABANDONO;

    @Override
    public String toString() {
        return  name() ;
    }
    
}
