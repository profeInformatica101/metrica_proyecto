/*
 * author: clara
 * Comparador que compara por la fecha en la que se disputan las carreras que quedan.
 */
package entidades;

import java.util.Comparator;

/**
 *
 * @author clara
 */
public class ComparadorFechaCarrera implements Comparator<Carrera> {
    @Override
    public int compare (Carrera c1, Carrera c2){
        return c1.getFecha().compareTo(c2.getFecha());
    }
}

