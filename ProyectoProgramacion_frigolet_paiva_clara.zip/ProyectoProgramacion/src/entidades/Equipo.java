/*
 * Clase Equipo
 */
package entidades;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author clara
 */
public class Equipo {

    private String nombre;
    private String pais;
    private List<Piloto> pilotos;

    public Equipo(String nombreEquipo, String pais) {
        this.nombre = nombreEquipo;
        this.pais = pais;
        this.pilotos = new ArrayList();
    }

    public void insertarPiloto(Piloto p) {
        pilotos.add(p);
        p.setEquipo(this);
    }

    public List<Piloto> getPilotos() {
        return pilotos;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    @Override
    public String toString() {

        String s = "Equipo\t\t\t" + "\n\nNombre: " + nombre + "\n\nPais: " + pais;
        return s;

    }
}
