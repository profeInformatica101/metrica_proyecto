/*
 * author: clara
 * Clase para obtener datos de la tabla de carreras de la base de datos
 */
package datos;

import entidades.Carrera;
import entidades.Circuito;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author clara
 */
public class DAOCarrera {

    public List<Carrera> obtenerTodasLasCarreras() {
        List<Carrera> carreras = new ArrayList<>();

        String sql = "select carrera.NOMBREGRANPREMIO, carrera.FECHA, circuito.nombre, circuito.localizacion, circuito.longitud, circuito.num_Vueltas"
                + " from carrera JOIN circuito ON carrera.circuito_id = circuito.id_circuito";
        try (Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521/xe", "formula1", "formula1"); Statement statement = conn.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {

                String nombre = resultSet.getString("NOMBREGRANPREMIO");
                LocalDate fecha = resultSet.getDate("FECHA").toLocalDate();

                String nombreCircuito = resultSet.getString("NOMBRE");
                String localizacion = resultSet.getString("LOCALIZACION");
                double longitud = resultSet.getDouble("LONGITUD");
                int numVueltas = resultSet.getInt("num_vueltas");
                Circuito circuito = new Circuito(nombreCircuito, localizacion, longitud, numVueltas);
                carreras.add(new Carrera(nombre, fecha, circuito));
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return carreras;
    }

    public Carrera buscarPornombreCarrera(String nombregranpremio) {
        Carrera c = null;
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            String sql = ("select carrera.NOMBREGRANPREMIO, carrera.FECHA, circuito.nombre, circuito.localizacion, circuito.longitud, circuito.num_Vueltas"
                    + " from carrera JOIN circuito ON carrera.circuito_id = circuito.id_circuito where lower(carrera.NOMBREGRANPREMIO)= lower(?)");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, nombregranpremio);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                String nombreCircuito = rs.getString("NOMBRE");
                String localizacion = rs.getString("LOCALIZACION");
                double longitud = rs.getDouble("LONGITUD");
                int numVueltas = rs.getInt("num_vueltas");
                Circuito circuito = new Circuito(nombreCircuito, localizacion, longitud, numVueltas);

                c = new Carrera(nombregranpremio, rs.getDate("fecha").toLocalDate(), circuito);

            }

        } catch (SQLException e) {
            System.err.println("buscarPornombreUsuario: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return c;
    }
}
