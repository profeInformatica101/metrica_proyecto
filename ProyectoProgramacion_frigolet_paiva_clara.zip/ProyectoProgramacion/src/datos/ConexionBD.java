/*
 * author: clara
 * Clase para la conexi�n con la base de datos formula 1
 */
package datos;

import entidades.Usuario;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author clara
 */
public class ConexionBD {

    public static Connection conectarBD() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe", "formula1", "formula1");
        return conn;
    }

    public static void desconetarBD(Connection conn) {
        try {
            conn.close();
        } catch (SQLException e) {
            System.err.println("Error al desconectar la BD: " + e.getMessage());
        }
    }

    //M�todo para la autenticaci�n del usuario
    public Usuario getUsuario(String nombreUsuario) {
        Usuario u = null; //Para que si no se encuentra, devuelva null.
        Connection conn = null;
        try {
            conn = conectarBD();
            PreparedStatement pst = conn.prepareStatement(
                    "select * from usuario where nombreUsuario= ?");
            pst.setString(1, nombreUsuario);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                u = new Usuario(nombreUsuario, rs.getString("password"), rs.getString("nombre"),
                        rs.getString("apellidos"), rs.getDate("fechanacimiento").toLocalDate(),
                        rs.getString("correo"), rs.getString("telefono"),
                        rs.getDouble("saldo"), rs.getBoolean("esAdmin"));

                u.setEsAdmin(rs.getBoolean("esAdmin"));

            }
        } catch (SQLException e) {
            System.err.println("getUsuario: " + e.getMessage());
        } finally {
            desconetarBD(conn);
        }

        return u;
    }
}
