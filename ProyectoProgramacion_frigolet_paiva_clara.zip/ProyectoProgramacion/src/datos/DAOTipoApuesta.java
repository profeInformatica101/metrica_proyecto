/*
 * author: clara
 * Clase para obtener datos de la tabla de tipos de apuestas de la base de datos
 */
package datos;

import entidades.Tipo;
import entidades.TipoApuesta;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author clara
 */
public class DAOTipoApuesta {

    public List<TipoApuesta> obtenerTodosLosTiposApuesta() {
        List<TipoApuesta> tipos = new ArrayList<>();

        String sql = "select * from tipoapuesta";
        try (Connection conn = DriverManager.getConnection(
                "jdbc:oracle:thin:@localhost:1521/xe", "formula1", "formula1"); Statement statement = conn.createStatement()) {
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {

                String tipoString = resultSet.getString("tipo");
                Tipo tipo = Tipo.valueOf(tipoString);
                String desc = resultSet.getString("descripcion");
                tipos.add(new TipoApuesta(tipo, desc));
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tipos;
    }

    public TipoApuesta buscarPornombreTipoApuesta(String tipo) {
        TipoApuesta t = null;
        Connection conn = null;
        try {
            conn = ConexionBD.conectarBD();
            String sql = ("select * from tipoapuesta where lower(tipo)= lower(?)");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, tipo);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String tipoString = rs.getString("tipo");
                Tipo type = Tipo.valueOf(tipoString);
                t = new TipoApuesta(type, rs.getString("descripcion"));

            }

        } catch (SQLException e) {
            System.err.println("buscarPornombreUsuario: " + e.getMessage());
        } finally {
            ConexionBD.desconetarBD(conn);
        }
        return t;
    }
}
